# Commonplace

A local workspace for documents, spreadsheets, and presentations, built with **Node.js 24, React 19, and SQLite**. Choose Docs, Sheets, or Slides from the home screen; each opens in a separate browser tab.

## Run

```sh
npm ci --ignore-scripts
npm run build
npm start
```

Open **http://127.0.0.1:4174**. The installed dependencies and production build are already present in this working copy. `npm run dev` starts the API on 4174 and Vite on 5174. Stop the production server before using dev mode. Set `PORT` for a different production port or `COMMONPLACE_DB` to choose a different SQLite file.

```sh
npm test
npm run build
npm run package
```

The package command creates a ZIP containing the source, build, lockfile, tests, and launch instructions, excluding personal data and installed dependencies.

## Included

| Area | Working features |
| --- | --- |
| Workspace | App launcher, separate editor tabs, files, search, type filters, sorting, grid/list views, folders, favourites, copies, recoverable trash, file import/export, workspace backup/import |
| Saving | SQLite persistence, automatic save, per-tab draft recovery on reload, concurrent-save conflicts, named versions, restoration, local comments/notes, resolve/reopen |
| Docs | Rich text, headings, font/size/colour/highlight, alignment, links, lists, tables with row/column operations, local images, outline, find/replace, word counts, page setup, page breaks, headers/footers/page numbers, undo/redo, browser spelling, DOCX/HTML/text export, basic DOCX/HTML/text import, print/PDF |
| Sheets | Editable grid, TSV paste/copy, ranges, formulas, cross-sheet references, relative/absolute reference copying, formatting, number/currency/percent/date formats, insert/delete rows and columns, column resizing, freeze row, tabs, sort/filter, fill, find, charts, conditional formatting, dropdown validation, simple pivot tables, CSV/TSV/JSON/XLSX import/export |
| Slides | Slides, layouts, themes, text, shapes, images, drag/resize, position controls, alignment, object order, duplicate/reorder, undo/redo, speaker notes, fullscreen presentation with keyboard controls, fade transition, PPTX/HTML/SVG/JSON export, basic PPTX/JSON import, print/PDF |

Office imports/exports use local OOXML readers/writers. They preserve common content; complex Office files can lose unsupported structures. No Microsoft Office or LibreOffice rendering comparison has been completed. Keep originals of important files.

The formula engine is an interpreted parser and never executes formula text as JavaScript. It implements arithmetic/comparisons, references/ranges, lazy IF/IFERROR, common aggregates, criteria functions, text functions, and basic lookup functions. It does not implement all Google Sheets functions. See `src/lib/formulas.js` for the exact function surface.

## Storage and recovery

Data lives in `data/commonplace.sqlite`, with SQLite WAL sidecars during use. Home → **Export backup** downloads files, folders, comments, and retained version history. **Import** appends a backup with new identifiers and preserves existing files. Requests are limited to 18 MB and each file to 15 MB; large workspaces should also be backed up by stopping the server and copying the complete data directory.

Unsaved drafts are kept separately in each tab's session storage and recovered on reload in that tab. They are cleared only after a successful save. Closing a tab while work remains unsaved shows the browser's leave warning. A tab's draft is not a substitute for the SQLite database or an exported backup. Save errors offer a recovery download. Conflicting edits can use the saved version, save a separate copy, or save the current draft as a new latest version. These are conflict controls, not simultaneous collaborative editing.

## Scope and parity

The user explicitly excluded sharing and credential-dependent features. This build has no accounts, public sharing, OAuth, Google services, AI credentials, or external collaboration. It binds to loopback for use on this computer.

**This is a working independent suite, not a fully verified reproduction of every Google Docs, Sheets, and Slides capability.** The REA investigation is `PARTIAL`, and the rebuild record remains `IN_PROGRESS`. Google required account verification, so no credential-gated editor was inspected or modified. Public Google product documentation informed the inventory; original private source and server behaviour are unknown.

Remaining families include complete Office round-trip fidelity, Docs tabs and suggestion tracking, citations/equations/footnotes, advanced pagination and image wrapping, the full Sheets function catalogue, advanced chart/pivot/filter/protection behaviour, complex Slides masters/animations/media, exhaustive accessibility and print parity, and matched comparisons with original editors. See `.rea-rebuild/INVENTORY.md`, `WORK.json`, and `REBUILD.json` for continuing work. Excluded sharing/authentication features are recorded separately and are not counted as delivered.

## Implementation

- React application with lazy-loaded editors and an original shared library interface.
- Tiptap/ProseMirror document editor, custom spreadsheet interpreter/grid, custom SVG-backed slide canvas.
- Node HTTP API with native `fetch` in the client and built-in `node:sqlite` storage.
- Same-origin browser writes, bounded data validation, escaped exports, and constrained rich-text imports.
- Browser `BroadcastChannel` synchronises local tabs without holding an HTTP connection per editor.
- System fonts are fallbacks if optional Google Fonts cannot load; no credentials are needed to run any feature.

No deployment, publication, spending, external account changes, or external messages were performed.
