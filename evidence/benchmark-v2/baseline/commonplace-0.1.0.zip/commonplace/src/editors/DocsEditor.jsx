import React, { useCallback, useEffect, useRef, useState } from 'react';
import { EditorContent, useEditor } from '@tiptap/react';
import { Extension, Node, mergeAttributes } from '@tiptap/core';
import StarterKit from '@tiptap/starter-kit';
import TextAlign from '@tiptap/extension-text-align';
import { TextStyle } from '@tiptap/extension-text-style';
import Color from '@tiptap/extension-color';
import Highlight from '@tiptap/extension-highlight';
import Image from '@tiptap/extension-image';
import { Table, TableRow, TableHeader, TableCell } from '@tiptap/extension-table';
import { AlignCenter, AlignJustify, AlignLeft, AlignRight, Bold, ChevronDown, ChevronLeft, ChevronRight, FileText, Highlighter, ImagePlus, Italic, Link2, List, ListOrdered, Minus, PanelLeft, Plus, Printer, Redo2, RemoveFormatting, Search, Strikethrough, Table2, Underline, Undo2, X } from 'lucide-react';
import { sanitizeHtml } from '../lib/sanitize.js';
import { createDocx, documentHtml, downloadDocument } from './docsExport.js';
import { importDocx } from './docsImport.js';
import './docs.css';

const FontStyle = Extension.create({
  name: 'fontStyle',
  addGlobalAttributes() {
    return [{ types: ['textStyle'], attributes: {
      fontSize: { default: null, parseHTML: (element) => element.style.fontSize || null, renderHTML: (attributes) => attributes.fontSize ? { style: `font-size: ${attributes.fontSize}` } : {} },
      fontFamily: { default: null, parseHTML: (element) => element.style.fontFamily || null, renderHTML: (attributes) => attributes.fontFamily ? { style: `font-family: ${attributes.fontFamily}` } : {} },
      backgroundColor: { default: null, parseHTML: (element) => element.style.backgroundColor || null, renderHTML: (attributes) => attributes.backgroundColor ? { style: `background-color: ${attributes.backgroundColor}` } : {} },
    } }];
  },
});

const PageBreak = Node.create({
  name: 'pageBreak', group: 'block', atom: true, selectable: true,
  parseHTML: () => [{ tag: 'div[data-type="page-break"]' }],
  renderHTML: ({ HTMLAttributes }) => ['div', mergeAttributes(HTMLAttributes, { 'data-type': 'page-break', class: 'docs-page-break' })],
});

const escapeHtml = (text) => text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const pageDefault = { size: 'a4', orientation: 'portrait', margin: 72, header: '', footer: '', pageNumbers: false };
const fontOptions = ['Arial', 'Georgia', 'Times New Roman', 'Verdana', 'Trebuchet MS', 'Courier New'];
const fontSizes = [8, 9, 10, 11, 12, 14, 16, 18, 20, 24, 28, 32, 36, 48, 60, 72];
const colorInput = (value, fallback) => {
  if (/^#[a-f\d]{6}$/i.test(value || '')) return value;
  const rgb = String(value || '').match(/^rgba?\((\d+),\s*(\d+),\s*(\d+)/);
  return rgb ? `#${rgb.slice(1).map((number) => Math.max(0, Math.min(255, Number(number))).toString(16).padStart(2, '0')).join('')}` : fallback;
};

function getOutline(editor) {
  if (!editor) return [];
  const headings = [];
  editor.state.doc.descendants((node, position) => {
    if (node.type.name === 'heading') headings.push({ level: node.attrs.level, text: node.textContent || 'Untitled heading', position });
  });
  return headings;
}

function findMatches(editor, query, matchCase) {
  if (!editor || !query) return [];
  const matches = [];
  const pattern = new RegExp(query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), matchCase ? 'g' : 'gi');
  editor.state.doc.descendants((block, position) => {
    if (!block.isTextblock) return;
    let text = '';
    const positions = [];
    block.descendants((node, offset) => {
      if (node.isText) {
        for (let index = 0; index < node.text.length; index++) {
          text += node.text[index];
          positions.push(position + 1 + offset + index);
        }
      } else if (node.type.name === 'hardBreak') {
        text += '\n';
        positions.push(position + 1 + offset);
      }
    });
    pattern.lastIndex = 0;
    for (const match of text.matchAll(pattern)) {
      matches.push({ from: positions[match.index], to: positions[match.index + match[0].length - 1] + 1 });
    }
    return false;
  });
  return matches;
}

function ToolButton({ icon: Icon, label, onClick, active, disabled, children, className = '' }) {
  return <button type="button" className={`docs-tool ${active ? 'is-active' : ''} ${className}`} title={label} aria-label={label} aria-pressed={active === undefined ? undefined : Boolean(active)} disabled={disabled} onMouseDown={(event) => event.preventDefault()} onClick={onClick}>{Icon && <Icon size={17} strokeWidth={1.8} />}{children}</button>;
}

export default function DocsEditor({ content, onChange, readOnly = false, onReady }) {
  const contentRef = useRef(content || {});
  const onChangeRef = useRef(onChange);
  const readOnlyRef = useRef(readOnly);
  const editorRef = useRef(null);
  const actionsRef = useRef({});
  const imageInput = useRef(null);
  const fileInput = useRef(null);
  const paperRef = useRef(null);
  const fileMenuRef = useRef(null);
  const findRef = useRef(null);
  const [revision, setRevision] = useState(0);
  const [outlineOpen, setOutlineOpen] = useState(true);
  const [menu, setMenu] = useState(null);
  const [zoom, setZoom] = useState(100);
  const [paperHeight, setPaperHeight] = useState(1123);
  const [notice, setNotice] = useState('');
  const [findOpen, setFindOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [replacement, setReplacement] = useState('');
  const [matchCase, setMatchCase] = useState(false);
  const [matchIndex, setMatchIndex] = useState(0);
  const [linkDialog, setLinkDialog] = useState(false);
  const [linkUrl, setLinkUrl] = useState('');
  const [pageDialog, setPageDialog] = useState(false);
  const [pageDraft, setPageDraft] = useState(pageDefault);
  const [tableRows, setTableRows] = useState(3);
  const [tableCols, setTableCols] = useState(3);
  contentRef.current = content || {};
  onChangeRef.current = onChange;
  readOnlyRef.current = readOnly;

  const inform = useCallback((message) => setNotice(message), []);
  const insertImages = useCallback(async (files) => {
    if (readOnlyRef.current) return;
    for (const file of files) {
      if (!file.type.startsWith('image/')) continue;
      if (file.size > 8 * 1024 * 1024) { inform('Choose an image smaller than 8 MB.'); continue; }
      try {
        const source = await new Promise((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(reader.result); reader.onerror = reject; reader.readAsDataURL(file); });
        if (!readOnlyRef.current) editorRef.current?.chain().focus().setImage({ src: source, alt: file.name }).run();
      } catch { inform('This image could not be opened. Try a PNG or JPEG.'); }
    }
  }, [inform]);

  const editor = useEditor({
    extensions: [
      StarterKit.configure({ link: { openOnClick: false, autolink: true } }),
      TextStyle, FontStyle, Color, Highlight.configure({ multicolor: true }),
      TextAlign.configure({ types: ['heading', 'paragraph'] }),
      Image.configure({ allowBase64: true, HTMLAttributes: { loading: 'lazy' } }),
      Table.configure({ resizable: true, HTMLAttributes: { class: 'docs-table' } }), TableRow, TableHeader, TableCell, PageBreak,
    ],
    content: sanitizeHtml(content?.html || '<p></p>'),
    editable: !readOnly,
    immediatelyRender: false,
    editorProps: {
      attributes: { class: 'docs-prose', spellcheck: 'true', 'aria-label': 'Document content', 'aria-multiline': 'true', role: 'textbox' },
      handlePaste: (_view, event) => {
        const files = [...(event.clipboardData?.files || [])].filter((file) => file.type.startsWith('image/'));
        if (!files.length || readOnlyRef.current) return false;
        event.preventDefault(); insertImages(files); return true;
      },
      handleDrop: (_view, event) => {
        const files = [...(event.dataTransfer?.files || [])].filter((file) => file.type.startsWith('image/'));
        if (!files.length || readOnlyRef.current) return false;
        event.preventDefault(); insertImages(files); return true;
      },
      transformPastedHTML: (html) => sanitizeHtml(html),
    },
    onUpdate: ({ editor: current }) => {
      onChangeRef.current?.({ ...contentRef.current, html: current.getHTML(), page: { ...pageDefault, ...contentRef.current.page } });
      setRevision((number) => number + 1);
    },
    onSelectionUpdate: () => setRevision((number) => number + 1),
    onTransaction: () => setRevision((number) => number + 1),
  });
  editorRef.current = editor;

  useEffect(() => { if (editor && editor.isEditable === readOnly) editor.setEditable(!readOnly); }, [editor, readOnly]);
  useEffect(() => {
    if (editor && content?.html !== undefined && content.html !== editor.getHTML()) {
      editor.commands.setContent(sanitizeHtml(content.html || '<p></p>'), { emitUpdate: false });
      setRevision((number) => number + 1);
    }
  }, [editor, content?.html]);
  useEffect(() => {
    if (!notice) return;
    const timer = setTimeout(() => setNotice(''), 5000);
    return () => clearTimeout(timer);
  }, [notice]);
  useEffect(() => {
    if (!paperRef.current) return;
    const observer = new ResizeObserver(([entry]) => setPaperHeight(entry.target.offsetHeight));
    observer.observe(paperRef.current);
    return () => observer.disconnect();
  }, [editor]);
  useEffect(() => {
    if (!menu) return;
    const close = (event) => { if (!fileMenuRef.current?.contains(event.target)) setMenu(null); };
    document.addEventListener('pointerdown', close);
    return () => document.removeEventListener('pointerdown', close);
  }, [menu]);
  useEffect(() => {
    const shortcuts = (event) => {
      const isMac = /Mac|iPhone|iPad/.test(navigator.platform);
      if ((isMac ? event.metaKey : event.ctrlKey) && event.key.toLowerCase() === 'f') { event.preventDefault(); setFindOpen(true); setTimeout(() => findRef.current?.focus(), 0); }
      if ((isMac ? event.metaKey : event.ctrlKey) && event.key.toLowerCase() === 'p') { event.preventDefault(); actionsRef.current.print?.(); }
      if ((isMac ? event.metaKey : event.ctrlKey) && event.key.toLowerCase() === 'k' && !readOnlyRef.current) { event.preventDefault(); actionsRef.current.openLink?.(); }
      if ((isMac ? event.metaKey : event.ctrlKey) && event.key === '\\' && !readOnlyRef.current) { event.preventDefault(); editorRef.current?.chain().focus().unsetAllMarks().clearNodes().run(); }
      if (event.key === 'Escape') { setMenu(null); setFindOpen(false); setLinkDialog(false); setPageDialog(false); }
    };
    document.addEventListener('keydown', shortcuts);
    return () => document.removeEventListener('keydown', shortcuts);
  }, []);

  const importFile = useCallback(async (file) => {
    if (readOnlyRef.current || !editorRef.current) return;
    if (!file) { fileInput.current?.click(); return; }
    if (file.size > 15 * 1024 * 1024) return inform('Choose a document smaller than 15 MB.');
    try {
      let html, importedPage, warnings = [];
      if (/\.docx$/i.test(file.name)) {
        const imported = await importDocx(file);
        html = sanitizeHtml(imported.html); importedPage = imported.page; warnings = imported.warnings || [];
      } else {
        const text = await file.text();
        html = /\.html?$/i.test(file.name) || file.type === 'text/html'
          ? sanitizeHtml(text)
          : text.split(/\n\s*\n/).map((paragraph) => `<p>${escapeHtml(paragraph).replace(/\n/g, '<br>')}</p>`).join('');
      }
      if (!readOnlyRef.current) {
        editorRef.current.commands.setContent(html || '<p></p>', { emitUpdate: false });
        onChangeRef.current?.({ ...contentRef.current, html: editorRef.current.getHTML(), page: { ...pageDefault, ...contentRef.current.page, ...importedPage } });
        setRevision((number) => number + 1);
        inform(`Imported ${file.name}.${warnings.length ? ` ${warnings.join(' ')}` : ''}`);
      }
    } catch (error) { inform(error.message || 'This file could not be opened. Import a Word, text, or HTML file.'); }
  }, [inform]);

  const exportHtml = useCallback(() => {
    const current = editorRef.current;
    if (current) downloadDocument('document.html', documentHtml(current.getHTML(), contentRef.current.page), 'text/html;charset=utf-8');
  }, []);
  const exportText = useCallback(() => {
    const current = editorRef.current;
    if (current) downloadDocument('document.txt', current.getText({ blockSeparator: '\n\n' }), 'text/plain;charset=utf-8');
  }, []);
  const exportDocx = useCallback(() => {
    try {
      const current = editorRef.current;
      if (current) downloadDocument('document.docx', createDocx(current.getHTML(), contentRef.current.page), 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');
    } catch { inform('The Word export could not be created. HTML export preserves the document formatting.'); }
  }, [inform]);
  const print = useCallback(() => {
    const current = editorRef.current;
    if (!current) return;
    const frame = document.createElement('iframe');
    frame.className = 'docs-print-frame';
    frame.title = 'Document print preview';
    frame.setAttribute('aria-hidden', 'true');
    frame.style.cssText = 'position:fixed;right:0;bottom:0;width:1px;height:1px;border:0;opacity:0;pointer-events:none';
    document.body.appendChild(frame);
    frame.onload = async () => {
      try {
        await Promise.all([...frame.contentDocument.images].map((img) => img.complete ? Promise.resolve() : new Promise((resolve) => { img.onload = resolve; img.onerror = resolve; })));
        await frame.contentDocument.fonts?.ready;
        frame.contentWindow.focus();
        frame.contentWindow.print();
        setTimeout(() => frame.remove(), 60000);
      } catch { frame.remove(); inform('Print preview could not be opened. Export HTML to print this document.'); }
    };
    frame.srcdoc = documentHtml(current.getHTML(), contentRef.current.page);
  }, [inform]);
  useEffect(() => {
    if (editor) onReady?.({ exportHtml, exportText, exportDocx, print, importFile, getHtml: () => editor.getHTML(), getText: () => editor.getText() });
  }, [editor, onReady, exportHtml, exportText, exportDocx, print, importFile]);

  const matches = findMatches(editor, query, matchCase);
  const outline = getOutline(editor);
  const words = editor?.getText().trim().match(/\S+/g)?.length || 0;
  const characters = editor?.getText().length || 0;
  const selection = editor?.state.selection;
  const selectedWords = selection && !selection.empty ? editor.state.doc.textBetween(selection.from, selection.to, ' ').trim().match(/\S+/g)?.length || 0 : 0;
  const page = { ...pageDefault, ...content?.page };
  const portraitWidth = page.size === 'letter' ? 816 : 794;
  const portraitHeight = page.size === 'letter' ? 1056 : 1123;
  const pageWidth = page.orientation === 'landscape' ? portraitHeight : portraitWidth;
  const pageHeight = page.orientation === 'landscape' ? portraitWidth : portraitHeight;
  const margin = Number(page.margin) || 72;
  const blockType = editor?.isActive('heading') ? `h${editor.getAttributes('heading').level}` : 'paragraph';
  const headingSizes = { 1: 26, 2: 20, 3: 16, 4: 14, 5: 12, 6: 12 };
  const fontSize = editor?.getAttributes('textStyle').fontSize || `${headingSizes[editor?.getAttributes('heading').level] || 11}pt`;
  const fontSizePoints = parseFloat(fontSize) * (fontSize.endsWith('px') ? 0.75 : 1);
  const fontFamily = (editor?.getAttributes('textStyle').fontFamily || 'Arial').split(',')[0].replace(/["']/g, '').trim();

  const run = (action) => { if (!readOnly && editor) action(editor.chain().focus()).run(); setMenu(null); };
  const jumpMatch = (index) => {
    if (!matches.length || !editor) return;
    const next = ((index % matches.length) + matches.length) % matches.length;
    setMatchIndex(next);
    editor.chain().setTextSelection(matches[next]).scrollIntoView().run();
  };
  const replaceMatch = (all) => {
    if (readOnly || !editor || !matches.length) return;
    const transaction = editor.state.tr;
    if (all) [...matches].reverse().forEach(({ from, to }) => transaction.insertText(replacement, from, to));
    else {
      const current = matches[Math.min(matchIndex, matches.length - 1)];
      transaction.insertText(replacement, current.from, current.to);
    }
    editor.view.dispatch(transaction);
    inform(all ? `Replaced ${matches.length} occurrence${matches.length === 1 ? '' : 's'}.` : 'Replaced one occurrence.');
    setMatchIndex(0);
  };
  const openLink = () => { setLinkUrl(editor?.getAttributes('link').href || ''); setLinkDialog(true); setMenu(null); };
  actionsRef.current = { print, openLink };
  const saveLink = (event) => {
    event.preventDefault();
    let url = linkUrl.trim();
    if (url && !/^[a-z][a-z\d+.-]*:/i.test(url)) url = `https://${url}`;
    if (url && !/^(https?:|mailto:|tel:)/i.test(url)) return inform('Use an https, email, or telephone link.');
    if (!readOnly && editor) {
      const chain = editor.chain().focus().extendMarkRange('link');
      if (url) chain.setLink({ href: url }).run(); else chain.unsetLink().run();
    }
    setLinkDialog(false);
  };
  const showPageSetup = () => { setPageDraft(page); setPageDialog(true); setMenu(null); };
  const savePage = (event) => {
    event.preventDefault();
    if (!readOnly) onChangeRef.current?.({ ...contentRef.current, html: editor?.getHTML() || '', page: pageDraft });
    setPageDialog(false);
  };
  const toggleMenu = (name) => setMenu((previous) => previous === name ? null : name);
  const menuItem = (label, action, shortcut, disabled = false) => <button key={label} type="button" role="menuitem" disabled={disabled} onMouseDown={(event) => event.preventDefault()} onClick={() => { action(); setMenu(null); }}><span>{label}</span>{shortcut && <span className="docs-shortcut">{shortcut}</span>}</button>;
  const menuItems = {
    File: <>{menuItem('Import Word, text, or HTML…', () => fileInput.current?.click(), null, readOnly)}<div className="docs-menu-separator" />{menuItem('Download as Word (.docx)', exportDocx)}{menuItem('Download as HTML (.html)', exportHtml)}{menuItem('Download as plain text (.txt)', exportText)}<div className="docs-menu-separator" />{menuItem('Page setup…', showPageSetup, null, readOnly)}{menuItem('Print / Save as PDF', print, '⌘ P')}</>,
    Edit: <>{menuItem('Undo', () => editor?.chain().focus().undo().run(), '⌘ Z', readOnly || !editor?.can().undo())}{menuItem('Redo', () => editor?.chain().focus().redo().run(), '⇧ ⌘ Z', readOnly || !editor?.can().redo())}<div className="docs-menu-separator" />{menuItem('Select all', () => editor?.chain().focus().selectAll().run(), '⌘ A')}{menuItem('Find and replace…', () => { setFindOpen(true); setTimeout(() => findRef.current?.focus(), 0); }, '⌘ F')}</>,
    View: <>{menuItem(`${outlineOpen ? 'Hide' : 'Show'} document outline`, () => setOutlineOpen(!outlineOpen))}{menuItem('Zoom to 100%', () => setZoom(100))}{menuItem('Zoom to 75%', () => setZoom(75))}{menuItem('Zoom to 125%', () => setZoom(125))}</>,
    Insert: <>{menuItem('Image from computer…', () => imageInput.current?.click(), null, readOnly)}{menuItem('Table…', () => setTimeout(() => setMenu('Table'), 0), null, readOnly)}{menuItem('Link…', openLink, '⌘ K', readOnly)}<div className="docs-menu-separator" />{menuItem('Horizontal line', () => run((chain) => chain.setHorizontalRule()), null, readOnly)}{menuItem('Page break', () => run((chain) => chain.insertContent({ type: 'pageBreak' })), null, readOnly)}{menuItem('Header, footer, and page numbers…', showPageSetup, null, readOnly)}</>,
    Format: <>{menuItem('Bold', () => run((chain) => chain.toggleBold()), '⌘ B', readOnly)}{menuItem('Italic', () => run((chain) => chain.toggleItalic()), '⌘ I', readOnly)}{menuItem('Underline', () => run((chain) => chain.toggleUnderline()), '⌘ U', readOnly)}{menuItem('Strikethrough', () => run((chain) => chain.toggleStrike()), null, readOnly)}<div className="docs-menu-separator" />{menuItem('Block quote', () => run((chain) => chain.toggleBlockquote()), null, readOnly)}{menuItem('Code block', () => run((chain) => chain.toggleCodeBlock()), null, readOnly)}{menuItem('Clear formatting', () => run((chain) => chain.unsetAllMarks().clearNodes()), '⌘ \\', readOnly)}</>,
    Tools: <>{menuItem('Find and replace…', () => { setFindOpen(true); setTimeout(() => findRef.current?.focus(), 0); }, '⌘ F')}{menuItem('Word count', () => inform(`${words.toLocaleString()} words · ${characters.toLocaleString()} characters${selectedWords ? ` · ${selectedWords} selected words` : ''}`))}{menuItem('Spelling', () => inform('Browser spelling is enabled. Right-click an underlined word to see suggestions.'))}</>,
  };

  if (!editor) return <div className="docs-loading">Opening your document…</div>;

  return <div className={`docs-editor ${readOnly ? 'docs-read-only' : ''}`} data-revision={revision}>
    <div className="docs-menu-bar" ref={fileMenuRef}>
      <div className="docs-menus" role="menubar" aria-label="Document menus">
        {Object.keys(menuItems).map((name) => <div key={name} className="docs-menu-wrap"><button type="button" role="menuitem" className={menu === name ? 'is-open' : ''} aria-haspopup="menu" aria-expanded={menu === name} onClick={() => toggleMenu(name)}>{name}</button>{menu === name && <div role="menu" className="docs-dropdown">{menuItems[name]}</div>}</div>)}
      </div>
      <span className="docs-editing-mode"><span className={readOnly ? 'is-viewing' : ''} />{readOnly ? 'Viewing' : 'Editing'}</span>
      {menu === 'Table' && <div role="menu" className="docs-dropdown docs-table-menu"><strong>Insert a table</strong><div className="docs-table-size"><label>Rows<input type="number" min="1" max="20" value={tableRows} onChange={(event) => setTableRows(Math.max(1, Math.min(20, Number(event.target.value) || 1)))} /></label><span>×</span><label>Columns<input type="number" min="1" max="12" value={tableCols} onChange={(event) => setTableCols(Math.max(1, Math.min(12, Number(event.target.value) || 1)))} /></label></div><button className="docs-primary" type="button" disabled={readOnly} onClick={() => run((chain) => chain.insertTable({ rows: tableRows, cols: tableCols, withHeaderRow: true }))}>Insert table</button></div>}
    </div>
    <div className="docs-toolbar" role="toolbar" aria-label="Text formatting">
      <ToolButton icon={Undo2} label="Undo (⌘ Z)" disabled={readOnly || !editor.can().undo()} onClick={() => run((chain) => chain.undo())} />
      <ToolButton icon={Redo2} label="Redo (⇧ ⌘ Z)" disabled={readOnly || !editor.can().redo()} onClick={() => run((chain) => chain.redo())} />
      <ToolButton icon={Printer} label="Print / Save as PDF" onClick={print} />
      <span className="docs-toolbar-divider" />
      <label className="docs-select docs-zoom-select"><span className="sr-only">Zoom</span><select aria-label="Zoom" value={zoom} onChange={(event) => setZoom(Number(event.target.value))}>{[50, 75, 90, 100, 110, 125, 150].map((value) => <option key={value} value={value}>{value}%</option>)}</select><ChevronDown size={13} /></label>
      <span className="docs-toolbar-divider" />
      <label className="docs-select docs-style-select"><span className="sr-only">Paragraph style</span><select aria-label="Paragraph style" disabled={readOnly} value={blockType} onChange={(event) => run((chain) => event.target.value === 'paragraph' ? chain.setParagraph() : chain.setHeading({ level: Number(event.target.value.slice(1)) }))}><option value="paragraph">Normal text</option>{[1, 2, 3, 4, 5, 6].map((level) => <option key={level} value={`h${level}`}>Heading {level}</option>)}</select><ChevronDown size={13} /></label>
      <span className="docs-toolbar-divider" />
      <label className="docs-select docs-font-select"><span className="sr-only">Font</span><select aria-label="Font" disabled={readOnly} value={fontFamily} onChange={(event) => run((chain) => chain.setMark('textStyle', { fontFamily: event.target.value }))}>{fontOptions.map((font) => <option key={font} value={font}>{font}</option>)}{!fontOptions.includes(fontFamily) && <option value={fontFamily}>{fontFamily}</option>}</select><ChevronDown size={13} /></label>
      <div className="docs-size-control"><ToolButton icon={Minus} label="Decrease font size" disabled={readOnly} onClick={() => run((chain) => chain.setMark('textStyle', { fontSize: `${Math.max(6, Math.round(fontSizePoints) - 1)}pt` }))} /><select aria-label="Font size" disabled={readOnly} value={fontSize} onChange={(event) => run((chain) => chain.setMark('textStyle', { fontSize: event.target.value }))}>{fontSizes.map((size) => <option key={size} value={`${size}pt`}>{size}</option>)}{!fontSizes.some((size) => `${size}pt` === fontSize) && <option value={fontSize}>{fontSizePoints}</option>}</select><ToolButton icon={Plus} label="Increase font size" disabled={readOnly} onClick={() => run((chain) => chain.setMark('textStyle', { fontSize: `${Math.min(144, Math.round(fontSizePoints) + 1)}pt` }))} /></div>
      <span className="docs-toolbar-divider" />
      <ToolButton icon={Bold} label="Bold (⌘ B)" active={editor.isActive('bold')} disabled={readOnly} onClick={() => run((chain) => chain.toggleBold())} />
      <ToolButton icon={Italic} label="Italic (⌘ I)" active={editor.isActive('italic')} disabled={readOnly} onClick={() => run((chain) => chain.toggleItalic())} />
      <ToolButton icon={Underline} label="Underline (⌘ U)" active={editor.isActive('underline')} disabled={readOnly} onClick={() => run((chain) => chain.toggleUnderline())} />
      <ToolButton icon={Strikethrough} label="Strikethrough" active={editor.isActive('strike')} disabled={readOnly} onClick={() => run((chain) => chain.toggleStrike())} />
      <label className="docs-color-picker" title="Text color"><span className="docs-color-letter">A</span><span className="docs-color-swatch" style={{ background: editor.getAttributes('textStyle').color || '#202124' }} /><input aria-label="Text color" disabled={readOnly} type="color" value={colorInput(editor.getAttributes('textStyle').color, '#202124')} onChange={(event) => run((chain) => chain.setColor(event.target.value))} /></label>
      <label className="docs-color-picker" title="Highlight color"><Highlighter size={17} /><span className="docs-color-swatch" style={{ background: editor.getAttributes('highlight').color || '#ffe88b' }} /><input aria-label="Highlight color" disabled={readOnly} type="color" value={colorInput(editor.getAttributes('highlight').color, '#ffe88b')} onChange={(event) => run((chain) => chain.setHighlight({ color: event.target.value }))} /></label>
      <span className="docs-toolbar-divider" />
      <ToolButton icon={Link2} label="Insert link" active={editor.isActive('link')} disabled={readOnly} onClick={openLink} />
      <ToolButton icon={ImagePlus} label="Insert image" disabled={readOnly} onClick={() => imageInput.current?.click()} />
      <ToolButton icon={Table2} label="Insert table" disabled={readOnly} onClick={() => toggleMenu('Table')} />
      <span className="docs-toolbar-divider" />
      {[['left', AlignLeft], ['center', AlignCenter], ['right', AlignRight], ['justify', AlignJustify]].map(([alignment, Icon]) => <ToolButton key={alignment} icon={Icon} label={`Align ${alignment}`} active={editor.isActive({ textAlign: alignment })} disabled={readOnly} onClick={() => run((chain) => chain.setTextAlign(alignment))} />)}
      <span className="docs-toolbar-divider" />
      <ToolButton icon={List} label="Bulleted list" active={editor.isActive('bulletList')} disabled={readOnly} onClick={() => run((chain) => chain.toggleBulletList())} />
      <ToolButton icon={ListOrdered} label="Numbered list" active={editor.isActive('orderedList')} disabled={readOnly} onClick={() => run((chain) => chain.toggleOrderedList())} />
      <ToolButton icon={RemoveFormatting} label="Clear formatting" disabled={readOnly} onClick={() => run((chain) => chain.unsetAllMarks().clearNodes())} />
    </div>
    {editor.isActive('table') && <div className="docs-table-actions" role="toolbar" aria-label="Table actions"><Table2 size={14} /><span>Table</span>{[['Add row above', 'addRowBefore'], ['Add row below', 'addRowAfter'], ['Add column left', 'addColumnBefore'], ['Add column right', 'addColumnAfter'], ['Delete row', 'deleteRow'], ['Delete column', 'deleteColumn'], ['Toggle header', 'toggleHeaderRow'], ['Merge cells', 'mergeCells'], ['Split cell', 'splitCell'], ['Delete table', 'deleteTable']].map(([label, command]) => <button key={command} type="button" disabled={readOnly || !editor.can()[command]()} onMouseDown={(event) => event.preventDefault()} onClick={() => run((chain) => chain[command]())}>{label}</button>)}</div>}
    {findOpen && <div className="docs-find-panel"><div className="docs-find-row"><Search size={17} /><input ref={findRef} aria-label="Find in document" placeholder="Find in document" value={query} onChange={(event) => { setQuery(event.target.value); setMatchIndex(0); }} onKeyDown={(event) => { if (event.key === 'Enter') { event.preventDefault(); jumpMatch(matchIndex + (event.shiftKey ? -1 : 1)); } }} /><span className="docs-match-count">{matches.length ? `${Math.min(matchIndex + 1, matches.length)} of ${matches.length}` : query ? 'No results' : ''}</span><ToolButton icon={ChevronLeft} label="Previous match" disabled={!matches.length} onClick={() => jumpMatch(matchIndex - 1)} /><ToolButton icon={ChevronRight} label="Next match" disabled={!matches.length} onClick={() => jumpMatch(matchIndex + 1)} /><ToolButton icon={X} label="Close find" onClick={() => setFindOpen(false)} /></div><div className="docs-find-row"><input aria-label="Replace with" placeholder="Replace with" value={replacement} disabled={readOnly} onChange={(event) => setReplacement(event.target.value)} /><button type="button" disabled={readOnly || !matches.length} onClick={() => replaceMatch(false)}>Replace</button><button type="button" disabled={readOnly || !matches.length} onClick={() => replaceMatch(true)}>Replace all</button><label className="docs-case-option"><input type="checkbox" checked={matchCase} onChange={(event) => setMatchCase(event.target.checked)} />Match case</label></div></div>}
    <div className="docs-workspace">
      <aside className={`docs-outline ${outlineOpen ? '' : 'is-collapsed'}`} aria-label="Document outline"><button className="docs-outline-toggle" type="button" title={outlineOpen ? 'Hide outline' : 'Show outline'} aria-label={outlineOpen ? 'Hide outline' : 'Show outline'} onClick={() => setOutlineOpen(!outlineOpen)}><PanelLeft size={18} /></button>{outlineOpen && <><div className="docs-outline-label">DOCUMENT OUTLINE</div>{outline.length ? <nav>{outline.map((heading, index) => <button type="button" key={`${heading.position}-${index}`} style={{ paddingLeft: 16 + (heading.level - 1) * 12 }} onClick={() => editor.chain().setTextSelection(heading.position + 1).focus().scrollIntoView().run()}>{heading.text}</button>)}</nav> : <div className="docs-outline-empty">Headings you add to your document appear here.</div>}<div className="docs-outline-tip"><FileText size={15} /><span>A little space for your next big idea.</span></div></>}</aside>
      <div className="docs-canvas" onClick={(event) => { if (event.target === event.currentTarget) editor.commands.focus('end'); }}>
        <div className="docs-page-stage" style={{ width: pageWidth * zoom / 100, minHeight: Math.max(pageHeight, paperHeight) * zoom / 100 + 34 }}>
          <div className="docs-ruler" style={{ width: pageWidth, transform: `scale(${zoom / 100})` }} aria-hidden="true"><div className="docs-ruler-margin" style={{ width: margin }} /><div className="docs-ruler-numbers">{Array.from({ length: Math.floor((pageWidth - margin * 2) / 48) + 1 }, (_, index) => <span key={index}>{index % 2 === 0 ? index / 2 : ''}</span>)}</div><div className="docs-ruler-margin" style={{ width: margin }} /></div>
          <div ref={paperRef} className="docs-paper" style={{ width: pageWidth, minHeight: pageHeight, padding: margin, transform: `scale(${zoom / 100})`, '--docs-content-height': `${pageHeight - margin * 2}px` }}>{page.header && <div className="docs-page-header" style={{ left: margin, right: margin }}>{page.header}</div>}<EditorContent editor={editor} />{(page.footer || page.pageNumbers) && <div className="docs-page-footer" style={{ left: margin, right: margin }}><span>{page.footer}</span>{page.pageNumbers && <span>Page 1</span>}</div>}</div>
        </div>
      </div>
    </div>
    <footer className="docs-status"><span>{selectedWords ? `${selectedWords.toLocaleString()} selected / ` : ''}{words.toLocaleString()} words</span><span className="docs-status-dot">·</span><span>{characters.toLocaleString()} characters</span><span className="docs-status-spacer" /><button type="button" onClick={showPageSetup}>{page.size === 'letter' ? 'Letter' : 'A4'} · {page.orientation === 'landscape' ? 'Landscape' : 'Portrait'}</button><span className="docs-status-dot">·</span><span>{readOnly ? 'View only' : 'Local document'}</span></footer>
    {notice && <div className="docs-notice" role="status">{notice}<button type="button" aria-label="Dismiss notification" onClick={() => setNotice('')}><X size={15} /></button></div>}
    {linkDialog && <div className="docs-modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) setLinkDialog(false); }}><form className="docs-modal" role="dialog" aria-modal="true" aria-labelledby="docs-link-title" onSubmit={saveLink}><div className="docs-modal-heading"><h2 id="docs-link-title">Insert link</h2><ToolButton icon={X} label="Close link dialog" onClick={() => setLinkDialog(false)} /></div><label>Link address<input autoFocus type="text" value={linkUrl} onChange={(event) => setLinkUrl(event.target.value)} placeholder="https://example.com" /></label><div className="docs-modal-actions"><button type="button" disabled={readOnly} onClick={() => { editor.chain().focus().extendMarkRange('link').unsetLink().run(); setLinkDialog(false); }}>Remove link</button><button className="docs-primary" disabled={readOnly} type="submit">Apply</button></div></form></div>}
    {pageDialog && <div className="docs-modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) setPageDialog(false); }}><form className="docs-modal" role="dialog" aria-modal="true" aria-labelledby="docs-page-title" onSubmit={savePage}><div className="docs-modal-heading"><h2 id="docs-page-title">Page setup</h2><ToolButton icon={X} label="Close page setup" onClick={() => setPageDialog(false)} /></div><label>Paper size<select disabled={readOnly} value={pageDraft.size} onChange={(event) => setPageDraft({ ...pageDraft, size: event.target.value })}><option value="a4">A4 (21 × 29.7 cm)</option><option value="letter">Letter (8.5 × 11 in)</option></select></label><label>Orientation<select disabled={readOnly} value={pageDraft.orientation} onChange={(event) => setPageDraft({ ...pageDraft, orientation: event.target.value })}><option value="portrait">Portrait</option><option value="landscape">Landscape</option></select></label><label>Margins<select disabled={readOnly} value={pageDraft.margin} onChange={(event) => setPageDraft({ ...pageDraft, margin: Number(event.target.value) })}><option value="48">Narrow (½ inch)</option><option value="72">Normal (¾ inch)</option><option value="96">Wide (1 inch)</option></select></label><div className="docs-modal-divider" /><label>Header<input disabled={readOnly} maxLength={200} value={pageDraft.header || ''} placeholder="Optional header text" onChange={(event) => setPageDraft({ ...pageDraft, header: event.target.value })} /></label><label>Footer<input disabled={readOnly} maxLength={200} value={pageDraft.footer || ''} placeholder="Optional footer text" onChange={(event) => setPageDraft({ ...pageDraft, footer: event.target.value })} /></label><label className="docs-modal-check"><input type="checkbox" disabled={readOnly} checked={Boolean(pageDraft.pageNumbers)} onChange={(event) => setPageDraft({ ...pageDraft, pageNumbers: event.target.checked })} />Show page numbers in print and Word export</label><div className="docs-modal-actions"><button type="button" onClick={() => setPageDialog(false)}>Cancel</button><button className="docs-primary" disabled={readOnly} type="submit">Apply</button></div></form></div>}
    <input ref={imageInput} className="docs-hidden-input" type="file" accept="image/png,image/jpeg,image/gif,image/webp" multiple onChange={(event) => { insertImages([...event.target.files]); event.target.value = ''; }} />
    <input ref={fileInput} className="docs-hidden-input" type="file" accept=".docx,.txt,.html,.htm,.md,text/plain,text/html,application/vnd.openxmlformats-officedocument.wordprocessingml.document" onChange={(event) => { importFile(event.target.files[0]); event.target.value = ''; }} />
  </div>;
}
