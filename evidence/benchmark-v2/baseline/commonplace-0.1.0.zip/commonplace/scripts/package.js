import {readFileSync,readdirSync,statSync,writeFileSync} from 'node:fs';
import path from 'node:path';
import {zipSync} from 'fflate';
const root=process.cwd(),entries={};
function add(relative){const absolute=path.join(root,relative);if(statSync(absolute).isDirectory()){for(const item of readdirSync(absolute))add(path.posix.join(relative,item));}else entries['commonplace/'+relative]=new Uint8Array(readFileSync(absolute));}
for(const relative of ['src','server','public','scripts','tests','dist','package.json','package-lock.json','vite.config.js','index.html','README.md','.gitignore','.rea-rebuild/INVENTORY.md'])add(relative);
const name='commonplace-0.1.0.zip';writeFileSync(name,zipSync(entries,{level:6}));console.log(`Packaged ${Object.keys(entries).length} files into ${name}. SQLite data and dependencies are excluded.`);
