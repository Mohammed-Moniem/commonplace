# Application contract and inventory

Target: Google Docs, Google Sheets, and Google Slides on the web, current public product documentation inspected 18 October 2026. Target editor build/version is unknown. Replacement: Commonplace 0.1.0, Node.js/React/SQLite, local web application.

The original request is the complete three-editor capability surface with a common launcher and separate tabs. The user subsequently said: **“Skip the sharing and parts where it actually requires users to actually use credentials.”** This excludes accounts, sharing, cloud collaboration, credential-dependent integrations and AI. It does not remove local advanced editor behaviour. This document does not assert complete discovery or parity.

## Evidence and observation boundary

- `https://workspace.google.com/products/docs/`, `/products/sheets/`, `/products/slides/`: public descriptions, document formatting/templates/imports/history, spreadsheet data/formulas/charts, and presentation creation/presentation capabilities. These are source-supported product statements, not observed editor cases.
- Browser attempt at `https://docs.google.com/document/u/0/` reached Google's identity verification screen. No login or original-document writes were attempted. Account identifier is omitted from retained evidence.
- REA 6.7.0 executable/version and command capabilities were qualified in `evidence/rea-runtime-qualification.json`. This proves command advertisement only; original editor capture readiness is NOT_TESTED. No fake canonical REA Evidence IDs or runtime captures are created.
- Replacement runtime actions and focused tests are distinct from original-reference behavioural parity. Office reader/writer self-roundtrips do not prove compatibility with every Office producer.

## Detailed requirement families

| IDs | Observable behaviour and edge cases | Implementation | State |
| --- | --- | --- | --- |
| HUB-01 | Select each app from Home, open independent tab, handle blocked popup with usable link | Library.jsx | Implemented; browser observed |
| HUB-02 | File creation, search, type filter, sort, grid/list, deep link and loading/error/empty states | Library.jsx, server/index.js | Implemented; broader cases remain |
| HUB-03 | Folder creation, move file, remove folder without deleting documents | Library.jsx, store.js | Implemented; HTTP and browser checks |
| HUB-04 | Favourites, duplicate content, recoverable trash, restore | Library.jsx, Editor.jsx | Implemented; UI/API checks |
| HUB-05 | Import/export common files and whole workspace, append backup atomically, reject malformed content | Library.jsx, index.js | Implemented; core tests; native UI import coverage partial |
| SAVE-01 | Debounced durable save of title and content; process restart restores exact data | Editor.jsx, store.js | Implemented; actual Node restart test |
| SAVE-02 | Separate-tab conflicting writes do not overwrite silently; retain per-tab draft on reload; useful offline/save errors | Editor.jsx | Implemented; independent review found/fixed shared-draft bug; runtime cases continuing |
| SAVE-03 | Retain 100 recent saves plus named versions, restore makes a new version | Editor.jsx, store.js | Implemented; API tests |
| SAVE-04 | File notes, resolve/reopen, persistence and backup | Editor.jsx, index.js | Implemented; UI/API checks |
| DOC-01 | Text selection, headings, marks, fonts/size/colour/highlight, alignment, lists and links; undo/redo | DocsEditor.jsx | Implemented; independent UI subset checked |
| DOC-02 | Tables, row/column editing, local image insertion/import, outline | DocsEditor.jsx | Implemented; native checks partial |
| DOC-03 | Find/replace with case option, counts, spellcheck | DocsEditor.jsx | Implemented; find/replace browser observed |
| DOC-04 | A4/Letter, orientation/margins/page breaks, header/footer and page numbers | DocsEditor.jsx, docsExport.js | Implemented with continuous editing page and print pagination limitations |
| DOC-05 | Text/HTML/DOCX import and HTML/text/DOCX/PDF-print export; malformed files rejected | docsImport.js, docsExport.js | Implemented; browser parser roundtrips; Office reference fidelity unproven |
| DOC-06 | Document tabs, local suggesting/accept/reject, smart blocks/dropdowns, citations/equations/footnotes and advanced wrapping/pagination | pending | Required local family remains incomplete |
| SHEET-01 | Cell editing, arrows/Tab/Enter, ranges, copy/paste, fill, undo/redo, row/column edits and reference updating | SheetsEditor.jsx, formulas.js | Implemented; formula tests and browser paste |
| SHEET-02 | Formulas with relative/absolute/cross-sheet ranges, errors/cycles/lazy conditions and standard mathematical/text/lookup functions | formulas.js | Implemented subset; full Google function surface remains required gap |
| SHEET-03 | Number styles, text/fill/alignment, widths, freeze, add/rename/delete sheet | SheetsEditor.jsx | Implemented; broader UI cases pending |
| SHEET-04 | Sort/filter/find, line/column charts, conditional formatting and strict dropdown validation | SheetsEditor.jsx, sheetOperations.js | Implemented; pivot/rules/validation browser observed |
| SHEET-05 | Pivot grouping and SUM/COUNT/AVERAGE/MIN/MAX, actual output sheet, source refresh | sheetOperations.js | Implemented simple local pivots; advanced pivot scope incomplete |
| SHEET-06 | CSV/TSV/JSON/XLSX imports and exports, preserve common formulas/formats/sheets, reject invalid archives | sheetsFiles.js | Implemented; OOXML tests; imported charts/macros unsupported |
| SHEET-07 | Complete formula compatibility, named ranges, advanced charts/pivots/filter views/validations, merge/protection/large-grid and connected data without credentials where applicable | pending | Required local family remains incomplete |
| SLIDE-01 | Add/delete/duplicate/reorder slides; layouts/themes; editable text/shapes/images | SlidesEditor.jsx | Implemented; independent UI checked |
| SLIDE-02 | Drag/resize, numeric position/size, object layers and alignment, font styles, undo/redo | SlidesEditor.jsx | Implemented; independent coordinate persistence checked |
| SLIDE-03 | Speaker notes, fullscreen presentation, keyboard next/back/escape, simple fade | SlidesEditor.jsx | Implemented; independent presentation/reload checked |
| SLIDE-04 | PPTX import/export, embedded images and speaker notes, HTML/SVG/JSON export, print/PDF | slideExport.js | Implemented common objects; parser and archive checks, full Office parity unknown |
| SLIDE-05 | Slide masters, complex object/group transforms, complete object/slide animation, media, advanced speaker/presenter views, diagrams/charts/tables | pending | Required local family remains incomplete |
| UX-01 | Responsive home/editor surfaces, keyboard menus/modals, usable disabled/error/denied/recovery states and accessibility | all UI | Implemented baseline; exhaustive comparison pending |
| PKG-01 | Launch/built static assets/package without original Google services or credentials, preserve user data | scripts/package.js | Working launch/build; distribution check pending until packaged |

## Excluded by the user's refinement

Authentication, public sharing/access roles, coauthoring/live cursors, Google Drive sync, Meet/Calendar/Gmail integrations, external cloud storage/data sources requiring credentials, add-on stores requiring accounts, billing/admin, and cloud AI. A local file note and a local concurrent-save conflict are not substitutes counted as these excluded features.

## Acceptance boundary and next work

The app is a useful runnable increment. Whole-app acceptance is not earned by the passing functional tests. A complete inventory, original credential-free case corpus, matched feature/visual/persistence comparisons, full required local families, accessibility/Office checks, and an independent final exact-source review are still needed. Preserve these gaps in WORK.json; do not call the build a complete Google Workspace replacement.
